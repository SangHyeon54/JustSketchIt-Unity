namespace JSI.AppObject {
    //this is concrete class
    public class JSIAppNoGeom3D : JSIAppObject3D {
        public JSIAppNoGeom3D(string name) : base($"{ name }/NoGeom3D") {
            
        }
        protected override void addComponents() {
                
        }
    }
}