namespace X {
    public interface XExecutable {
        // public abstract bool execute();
        // interface method is primarilly public abstract
        bool execute();
    }
}
