namespace JSI.Geom {
    public abstract class JSIGeom2D : JSIGeom {
    }
}