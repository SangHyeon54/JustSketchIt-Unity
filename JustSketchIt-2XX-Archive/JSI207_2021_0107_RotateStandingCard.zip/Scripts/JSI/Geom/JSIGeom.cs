namespace JSI.Geom {
    public abstract class JSIGeom {

    }
}